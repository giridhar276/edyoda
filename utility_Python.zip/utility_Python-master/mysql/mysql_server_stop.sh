#!/bin/sh

mysql.server stop