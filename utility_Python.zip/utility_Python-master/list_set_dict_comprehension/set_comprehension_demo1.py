"""
Python set comprehension demo 1 

"""
sample_list = ['a', 'a', 'a', 'b', 'b' , 'c', 'd']

my_set1 = set( i for i in sample_list )

print (my_set1)