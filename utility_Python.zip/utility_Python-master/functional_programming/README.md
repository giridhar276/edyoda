# functional_programming

- Definition 
	- Pure function : the function should `always` return `the same output` with same input

	- No side effect : the fuction never affect (interact) `outside of the world`