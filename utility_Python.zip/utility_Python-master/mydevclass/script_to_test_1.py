def add_func(x):
    try:
        return x + 5
    except TypeError:
        return False 