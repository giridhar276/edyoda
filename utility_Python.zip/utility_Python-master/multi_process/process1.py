# process1.py
from time import sleep                                                          
                                                                                
sleep(10)                                                                       
print('End of process 1')