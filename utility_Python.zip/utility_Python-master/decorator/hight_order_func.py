"""
hight order function : a function which can 
	1) accept an input as a function
	2) return function as an output

"""

# function as input 
def greet(func):
	func 

# function as output 
def greet2():
	def func():
		return 5 
	return func