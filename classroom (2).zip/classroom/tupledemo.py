
alist = [30,434,32,3]
alist[0] = 400
print("After replacing :" , alist)



atup = (56,54,43,4)

#atup[0] = 900
print("After replacing :", atup)



print("-------------------")
# typecasting
atup = (56,54,43,4)
# converting from tuple to list
alist = list(atup)
# make changes
alist.append(4567)
# reconvert back
atup = tuple(alist)
print(atup)




