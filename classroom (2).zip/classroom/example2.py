


alist = [12,23,34,54,43,56,45,67,43,99,98,87,88]

'''
#output
even numbers: 8
odd numbers : 4
'''

evenlist = []
oddlist = []
for val in alist:
    if val % 2 == 0 :
        evenlist.append(val)
    else:
        oddlist.append(val)

print("No. of even numbers :", len(evenlist))
print("No. of odd numbers  :", len(oddlist))
        
