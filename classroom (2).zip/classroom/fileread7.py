'''
#Write a Python program to read realestate.csv and
#replace all the lines containing SACRAMENTO with BANGALORE

## display only street and city
with open('realestate.csv','r') as fobj:
    # processing 
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        output = line.replace('SACRAMENTO','BANGALORE')
        print(output)
        
    print("No. of cities :", len(set(citylist)))
'''

## display only street and city
with open('realestate.csv','r') as fobj:
    # processing 
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        if 'SACRAMENTO' in line:
            line = line.replace('SACRAMENTO','BANGALORE')    
        print(line)
        
    print("No. of cities :", len(set(citylist)))
