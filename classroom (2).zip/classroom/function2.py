

## function returning value
# function block
def display(a,b):
    c = a + b
    return c


# calling function
print(display(10,20))
