




# importing all the methods
import math
print(math.tan(2))
print(math.log(2))



# importing library with alias
import math as m
print(m.tan(2))
print(m.sin(1))


# importing required methods ONLY
# since the methods are imported directly . is not required
from math import tan,cos,log
print(tan(3))
print(cos(1))
print(log(1))
