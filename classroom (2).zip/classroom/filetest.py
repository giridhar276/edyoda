


fobj = open("data.txt","r")


print(fobj.read(2))
print("\n")
print(fobj.read(2))


fobj.close()
