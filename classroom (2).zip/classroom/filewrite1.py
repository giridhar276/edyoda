# traditional writing to the file
# If the file is not existing .. file gets created first
# If the file is already existings ... it overwrites
fobj = open("customers.txt","w")
fobj.write('unix\n')
fobj.write('java\n')

fobj.close()

# append
# If the file is not existing .. file gets created first
# If the file is already existing ... it appends the data to the existing file

# writing numbers to the file
fobj = open("customers1.txt","a")
for line in range(1,10):
    fobj.write(str(line) + "\n")
fobj.close()


# modern style - pythonic way
# context manager
# Advantage : file will be closed automatically
with open("string.txt","w") as fobj:
    fobj.write('python programming\n')
    fobj.write('java\n')




    
