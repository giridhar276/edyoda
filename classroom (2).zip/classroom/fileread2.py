



#  fobj can be called as file object or file handler or pointer
with open('data.txt','r') as fobj:
    for line in fobj:
        #remove any whitespaces
        line = line.strip()
        output = line.split(",")
        print(output[0])


print("---------------------")
# just display the lines containing python
#  fobj can be called as file object or file handler or pointer
with open('data.txt','r') as fobj:
    for line in fobj:
        #remove any whitespaces
        line = line.strip()
        if 'Python'.lower() in line.lower():
            print(line)
