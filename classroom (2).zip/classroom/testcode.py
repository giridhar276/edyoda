


try:
    hello()
except:
    print('error')