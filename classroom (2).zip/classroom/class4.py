import pdb
pdb.set_trace()
class Employee:
    def __init__(self,name,sal,address):
        self.name= name
        self.sal = sal
        self.address = address
    def displayInfo(self):
        print("Employee name is",self.name)
        print("Employee salary is",self.sal)
        print("Employeee address is" , self.address)
        

# Whenever the object is created, constructor(__init__) is invoked automatically
# Constructor will be invoked automatically
emp1 = Employee('Ram',30000,'Hyderabad')
emp1.displayInfo()

emp2 = Employee('Rita',40000,'Mumbai')
emp2.displayInfo()