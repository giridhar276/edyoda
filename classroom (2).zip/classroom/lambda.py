
## function returning value
# function block
def display(a,b):
    c = a + b
    return c
# calling function
print(display(10,20))




#lambda function
#inline function
#nameless function
# lambda is replacement of single line function
# Instead of calling the function body
#  it gets replaced in calling function
# Advantage : performance is better compared to writing 

#syntax:
#functionname = lambda variables:expression

display = lambda x,y : x + y
print(display(10,20))


convert = lambda x : x.upper()
print(convert('python'))



convert = lambda *x : sum(x)
print(convert(1,2,3,4,5,6,7))


#map()
#filter

#write a program to read the list and the below output
alist = [10,20,30,40,50]

#output: [15,25,35,45,55]
blist = []
for i in alist:
    blist.append(i + 5)
print(blist)


alist = ["google","java","oracle"]

#output
["www.google.com","www.java.com","www.oracle.com"]
for val in alist:
    print("www." + val + ".com")



alist = [10,20,30,40,50]

#output: [15,25,35,45,55]
blist = []
for i in alist:
    blist.append(i + 5)
print(blist)


alist = [10,20,30,40,50]
def increment(x):
    return x + 5
print(list(map(increment,alist)))


alist = [10,20,30,40,50]
print(list(map( lambda x:x+5,alist)))



output = ['1','2','3','4','5']
print(list(map(int,alist)))


alist = ["google","java","oracle"]
print((list(map(lambda x : "www." + x + ".com" , alist))))



output = [1,2,3,4,5,6,7,8,9]
for val in output:
    if val % 2 == 0:
        print(val)

# filter(function,iterable)
print(list(filter(lambda x: x%2==0 ,output)))  # even
print(list(filter(lambda x: x%2  ,output)))      # odd


data = ["unix","oracle","linux","java"]
print(list(filter(lambda x: len(x)==4  ,data))) 






alist = [10,20,30,40,50]
print(list(map( lambda x:x+5,alist)))

# list comprehension
alist = [10,20,30,40,50]
output = [  val + 5   for val in alist ]
print(output)

output = [s.lower() for s in "I stay in Hyderabad"]
print(output)


squares = [ x * x for x in (1, 2, 3, 4) ]
print(squares)


output = [word.strip(',') for word in ['Python,', 'is,', 'general', 'purpose,', 'programming,', 'language,'] ]
print(output)




output = [sorted(x) for x in [[20, 10], [43, 33], [5, 10]]]
print(output)



output =[x if x in 'aeiou' else '*' for x in 'python programming']
print(output)



output =  { x for x in range(10)} 
print(output)




