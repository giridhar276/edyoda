


with open('data.txt','r') as fobj:
    print(fobj.readlines())
    print('------')

    print(fobj.read(2))
