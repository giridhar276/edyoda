
class Employee:
    def getEname(self):
        print("Employee name is","Rao")
    def displayEsal(self):
        print("Employee salary is",70000)
    def displayAddress(self):
        print("Employeee address is" , 90000)
        
emp1 = Employee()
emp1.getEname()
emp1.displayEsal()
emp1.displayAddress()
