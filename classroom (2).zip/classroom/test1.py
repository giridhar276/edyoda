

print('hello python')

print('hello python')

print('hello python')

print('hello python')

print('hello python')