
#Write a Python program to capture any filename from the keyboard and
#display its filename and extension separately

'''
Output:
Enter any filename :  customerdata.py

Filename : customerdata
extension: py
'''

filename = input("Enter any filename :")
print("YOu entered :",filename)

if "." in filename :
    output = filename.split(".")

    print("Filename :", output[0])
    print("Extension:", output[1])
else:
    print("Wrong input...!!!")

