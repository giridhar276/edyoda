


import os


print(os.listdir())

print(os.environ)


os.rmdir('test')


