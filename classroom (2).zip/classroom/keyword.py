

# keyword args

def display(b,a):
    print(a,b)



display(a=10,b=20)
