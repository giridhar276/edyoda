


#input()
name = input('Enter any string :')
print('You entered', name)
print(type(name))

value = input("Enter any value :")
print("You entered ",value)
print(type(value))


# range()
for val in range(1,5):
    print(val)

# max() min() sum()
alist = [56,34,32,45]
print(max(alist))
print(min(alist))
print(sum(alist))



print(type(alist))
print(isinstance(alist,list))  # True
print(isinstance(alist,tuple)) # False
print(isinstance(alist,dict))#  False






      
