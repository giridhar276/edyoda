




#  fobj can be called as file object or file handler or pointer
with open('data.txt','r') as fobj:
    for line in fobj:
        #remove any whitespaces
        #line = line.strip()
        print(line)


    
