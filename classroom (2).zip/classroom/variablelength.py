

# variable length
def display(a,b,c,d,e):
    print(a,b,c,d,e)


display(10,20,30,40,50)



# variable length
def display(*arg):
    #print(arg)
    for val in arg:
        print(val)


display(10,20,30,40,50)




#   *  --> tuple
#   ** --> dictionary
# variable length
def display(**arg):
    #print(arg)
    for key,value in arg.items():
        print(key,value)


display(chap1=10 , chap2 = 20)



