

class Employee:
    def getEname(self,name):
        print("Employee name is",name)
    def displayEsal(self,sal):
        print("Employee salary is",sal)
    def displayAddress(self,address):
        print("Employeee address is" , address)
        
        
emp1 = Employee()
emp1.getEname('Ram')
emp1.displayEsal(30000)
emp1.displayAddress('Hyderabad')

emp2 = Employee()
emp2.getEname('Rita')
emp2.displayEsal(40000)
emp2.displayAddress('Mumbai')


