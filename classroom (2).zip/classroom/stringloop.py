

for i in range(1,11) :
    print(i)


print("even numbers")
for i in range(2,11,2):
    print(i)

# reading char by char
name = "python programming"
for char in name:
    print(char)


alist = [10,20,30,40]
for val in alist:
    print(val)


atup = (45,56,67,3,34)
for val in atup:
    print(val)


