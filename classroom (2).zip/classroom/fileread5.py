
# Write a Python program to read realestate.csv and
#display all the UNIQUE cities and the count of unique cities.



citylist  = list()

## display only street and city
with open('realestate.csv','r') as fobj:
    # processing 
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        output = line.split(",")
        city = output[1]
        citylist.append(city)
    # display the output
    for city in set(citylist):
        print(city)
    print("No. of cities :", len(set(citylist)))
