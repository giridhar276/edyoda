


# 1 to 10

for val in range(1,11):
    print(val)


# while
i=1
while i <=10 :
    print(i)
    i = i + 1
