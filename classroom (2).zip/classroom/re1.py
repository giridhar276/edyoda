import re
# to match only at the beginning
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("^python$",line):  
            print(line)


## $ match at the end
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("python$",line):  
            print(line)

# display line with exact pattern
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("^python$",line):  
            print(line)


#*  : zero or more occurences of preceding character
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt*hon",line):  
            print(line)


#+  : one or more occurences of preceding character
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        # t should exist atleast once
        if re.search("pyt+hon",line):  
            print(line)



# .  : any single character or digit
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search(".ython",line):  
            print(line)

#?  : either zero or one occurence o preceding character
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt?hon",line):    # python or pyhon
            print(line)


#character class
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("[pqmj1]ython",line):  # python nor mython or qython or jython or 1ytohn
            print(line)


#( | )  :  (python|perl)
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("python|perl",line): 
            print(line)


#{}   :  {min,max} occurence of preceding character
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{1,10}hon",line):  
            print(line)


with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{2}hon",line):  
            print(line)

            
'''




            














            




import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{2,6}hon",line):  
            print(line)

            


import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{1,10}hon",line):  
            print(line)
