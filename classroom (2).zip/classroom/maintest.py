





print(__name__)

