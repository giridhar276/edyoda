alist = [10,45,56,43,56]


if 10 in alist:
    print("exists")

#adding element to list
alist.append(12)
print("After appending :", alist)

print(alist.append(34))
print(alist)


alist.append(120)
print("After appending :", alist)

# extend - adding multiple elements
alist.extend([89,23,32,43,54])
print("After extending :", alist)


# insert() - add at any index
# list.insert(where to insert,what to insert)
# list.insert(index position, value)
alist.insert(1,1000)
print("After insert :", alist)


# remove() - if you know the element
alist.remove(45)
print("After removing :", alist)
# using in keyword
if 450 in alist:
    alist.remove(450)
    print('Element removed')
else:
    print('element not found')


# using count logic
getcount = alist.count(450)
if getcount > 0 :
    alist.remove(450)
    print('Element removed')
else:
    print('element not found')   




# pop() -  using index number
alist.pop(2) # value at 2nd index will be removed
print(alist)

# pop() -   if value is not mentioned, the last element gets deleted
alist.pop() # value at 2nd index will be removed
print(alist)



# count() - the no. of times value has been repeated
print(alist.count(1000))


# list.reverse() - to reverse all the elements in place
alist.reverse()
print(alist)


# list.sort()  - sorting the values from smallest to biggest by default
output = alist.sort()
print(output)
print("After sorting :", alist)

## sorting in descending order
alist.sort(reverse = True)
print("After sorting :", alist)






















          
