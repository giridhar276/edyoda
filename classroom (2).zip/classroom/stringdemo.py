


print(10,20)

print("value is " , 10)

print("python","scala","kafka")

val =10
print("value is ", val)

#string
name = "python programming"

print(name)
print("I love",name)

# slicing
#string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:4])
print(name[6:9])
print(name[0:17])
print(name[:])
print(name[::])
print(name[0:17:2])
print(name[1:17:2])
print(name[1::3])
print(name[::-2])   # string reverse
print(name[-1])


# string is immutable 
name = "python programming"
print("********")
print("Output :", name.capitalize())
print("********")

print(name.lower())
print(name.upper())
print(name)

#Characters inside the string cant be modified directly
#name[0] = 'z'  # this is invalid , 
print(name)

print(name.endswith("z"))
print(name.endswith("g"))

print(name.isupper())
print(name.islower())
name = "python programming"
print(name.split(" "))

print(name.count("p"))

print(name.replace("python","scala"))
print(name)

bname = " python  "
print(len(bname))






bname = " python  ".strip()
print(len(bname))


bname = " python  ".lstrip()
print(len(bname))


bname = " python  ".rstrip()
print(len(bname))






name = "python programming"
output = list(name)
print(output)
output[1]= output[1].upper()
print(output)
print("".join(output))






a,b = 100,20

if a < b :
    print("A is less than B")
    print("Inside if")
    print("Still if condition")
else:
    print("B is less than A")
    print("Inside else ")


name = "python programming"

if name.startswith("pyt"):
    print("String is starting with p")
else:
    print("String is starting with someother character")





if name.isupper():
    print("String is defined in uppercase")
else:
    print("String is defined in lowercase")






    





















