
# Write a Python program to read realestate.csv and
#display all the UNIQUE cities and the count of unique cities.

cityset  = set()



## display only street and city
with open('realestate.csv','r') as fobj:
    # processing 
    for line in fobj:
        # remove any white spaces and line breaks

        line =line.strip()
        output = line.split(",")
        city = output[1]
        cityset.add(city)
    # display the output
    for city in cityset:
        print(city)
    print("No. of cities :", len(cityset))
    
