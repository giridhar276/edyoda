

#Write a Python program to generate the following pattern using a loop number

#1 22 333 4444 55555 666666 7777777 88888888 999999999



val = int(input("Enter any value :"))
for i in range(1,val+1):
    print(str(i) * i , end= " ")




val = int(input("Enter any value :"))
for i in range(1,val+1):
    print(str(i) * i )

