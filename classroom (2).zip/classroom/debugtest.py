import pdb
pdb.set_trace()
a,b = 100,20

if a < b :
    print("A is less than B")
    print("Inside if")
    print("Still if condition")
else:
    print("B is less than A")
    print("Inside else ")


name = "python programming"

if name.startswith("pyt"):
    print("String is starting with p")
else:
    print("String is starting with someother character")





if name.isupper():
    print("String is defined in uppercase")
else:
    print("String is defined in lowercase")

