



import re
# to match only at the beginning
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("^python$",line):  
            print(line)
