
## display only street and city
with open('realestate.csv','r') as fobj:
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        output = line.split(",")
        print("Street :", output[0])
        print("City   :",output[1])
        print("---------------------")

'''
## display only street and city
with open('realestate.csv','r') as fobj:
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        output = line.split(',')
        print(output[0].ljust(20),"\t", output[1])
        
'''
