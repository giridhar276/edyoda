


'''
with open('data.txt','r') as fobj:
    print(fobj.readline())
    print(fobj.readline())
    print(fobj.readline())
    print(fobj.readline())
    print(fobj.readline())
'''

with open('data.txt','r') as fobj:
    for line in fobj:
        while True:
            line = fobj.readline()
            if not line:
                break
            print(line)
