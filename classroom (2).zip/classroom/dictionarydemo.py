book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)

print(book["chap1"])
print(book['chap1'])


# display keys
print(book.keys())

# display values
print(book.values())

# display items
#[(k,v),(k,v),(k,v)]
print(book.items())


#print(book['chap7'])
# if key is not existing then return None
print(book.get('chap7'))
# if key is existing return the value
print(book.get('chap1'))


# pop - delete key:value pair
book.pop("chap1")
print("After pop operation :", book)

book1 = {"chap4":40 ,"chap5":50}

book.update(book1)
print("After updating :", book)




book = {"chap1":10 ,"chap2":20 ,"chap3":30}

## display only keys
for k in book.keys():
    print(k)


for k in book:
    print(k)

## display values
for val in book.values():
    print(val)



# display key:value pairs
for k,v in book.items():
    print("Key  :", k)
    print("Value:", v)

# reading keys and display values
for k in book:
    print(book[k])


    


book = {"chap1":['Rita','US',100] ,"chap2":{"name":"sita","country":"US"} ,"chap3":30}

print(book['chap1'][0])


print(book['chap2']['name'])










