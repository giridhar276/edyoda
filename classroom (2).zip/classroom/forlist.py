

alist = [10,20,30,40,50,60,70,80,90,100]


for val in alist:
    print(val)


## break

for val in alist:
    if val == 60:
        break
    print(val)

    
for val in alist:
    print(val)
    if val == 60:
        break

print("Using continue ")
# continue
for val in alist:
    if val == 60:
        continue
    print(val)  
