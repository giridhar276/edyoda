

alist = [10,20,3]
for val in alist:
    break
    if val == 60:
        print(val)
