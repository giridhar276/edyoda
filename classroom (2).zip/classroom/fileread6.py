



# Write a Python program to read
#realestate.csv and display the count of an individual city.


citylist  = list()

## display only street and city
with open('realestate.csv','r') as fobj:
    # processing 
    for line in fobj:
        # remove any white spaces and line breaks
        line =line.strip()
        output = line.split(",")
        city = output[1]
        citylist.append(city)
    # display the output
    for city in set(citylist):
        print(city.ljust(20) , citylist.count(city), "times" )
    print("No. of cities :", len(set(citylist)))
