

import bikemodule

bikemodule.Bike(3000,400).displayInfo()


import os
import sys

print(os.listdir())