class Employee:
    def getInfo(self,name,sal,address):
        self.name= name
        self.sal = sal
        self.address = address
    def displayInfo(self):
        print("Employee name is",self.name)
        print("Employee salary is",self.sal)
        print("Employeee address is" , self.address)
        
        
emp1 = Employee()
emp1.getInfo('Ram',30000,'Hyderabad')
emp1.displayInfo()

emp2 = Employee()
emp2.getInfo('Rita',40000,'Mumbai')
emp2.displayInfo()
